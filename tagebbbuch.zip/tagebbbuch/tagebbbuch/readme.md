# LB 324

## Aufgabe 2
Erklären Sie hier, wie man `pre-commit` installiert.

## Aufgabe 4
Erklären Sie hier, wie Sie das Passwort aus Ihrer lokalen `.env` auf Azure übertragen.